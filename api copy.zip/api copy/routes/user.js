const router = require('express').Router();
const userManager = require('../managers/user');
const crypto = require('../utils/crypto');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { uuid } = require('uuidv4');
const emailManager = require("../managers/email");

const storage = multer.diskStorage({
    destination: (req, file, callback) => {
        const dir = path.join(__dirname, '../uploads/');
        if (!fs.existsSync(dir))
            fs.mkdirSync(dir);

        callback(null, dir);
    },
    filename: (req, file, callback) => {
        const fileKey = `${uuid()}${path.extname(file.originalname)}`;
        callback(null, fileKey);
    },
    originalname: (req, file, callback) => {
        callback(null, file.originalname);
    },
});
const upload = multer({ storage: storage }).single('file');

router.post('/signup', async (req, res) => {
    try {
        let user = await userManager.getByEmail(req.body.email);
        if (user)
            return res.status(400).send(`User already exists with this email.`);

        const obj = {
            ...req.body,
            password: await crypto.hash(req.body.password)
        };

        user = await userManager.create(obj);
        return res.status(200).send(user);
    } catch (ex) {
        return res.status(500).send(ex.message);
    }
});

router.post('/login', async (req, res) => {
    try {
        const user = await userManager.getByEmail(req.body.email);
        if (!user)
            return res.status(400).send(`User does not exists with this email.`);

        const passwordMatches = await crypto.compare(req.body.password, user.password);
        if (!passwordMatches)
            return res.status(400).send(`Password did not match.`);

        return res.status(200).send(user);
    } catch (ex) {
        return res.status(500).send(ex.message);
    }
});

router.get(`/:id`, async (req, res) => {
    try {
        const user = await userManager.getById(req.params.id);
        return res.status(200).send(user);
    } catch (ex) {
        return res.status(500).send(ex.message);
    }
});

router.post(`/find-teachers`, async (req, res) => {
    try {
        const keyword = req.body.keyword || ``;
        const users = await userManager.getAll(keyword);
        return res.status(200).send(users);
    } catch (ex) {
        return res.status(500).send(ex.message);
    }
});

router.put(`/upload/:id`, async (req, res) => {
    try {
        upload(req, res, async err => {
            if (err)
                return res.status(500).send(err);

            const file = req.file;
            const data = {
                id: req.params.id,
                imageUrl: file.filename
            };

            let user = await userManager.update(data);
            return res.status(200).send(user);
        });
    } catch (ex) {
        return res.status(500).send(ex.message);
    }
});

router.post(`/book-meeting`, async (req, res) => {
    try {
        console.log(req.body);
        let toUser = await userManager.getById(req.body.meetingToId);
        let fromUser = await userManager.getById(req.body.senderId);
        await emailManager.sendEmail({
            to: toUser.email,
            subject: 'Meeting invite received',
            html: `You have received a meeting invitation. Pleae check following details. <br/><br/>
                    Sender name: ${fromUser.name} <br/>
                    Sender email: ${fromUser.email}<br/>
                    Date & time: ${req.body.date}<br/>
                    Meeting title: ${req.body.title}<br/>
                    Meeting URL: ${req.body.link}
                    <br/><br/>Regards,<br/>Team Minimal Tutoring Platform.`
        });
        res.sendStatus(200);
    } catch (ex) {
        return res.status(500).send(ex.message);
    }
});

module.exports = router;