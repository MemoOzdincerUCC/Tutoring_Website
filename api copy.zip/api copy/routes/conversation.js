const router = require('express').Router();
const conversationManager = require('../managers/conversation');

router.post('/', async (req, res) => {
    try {
        let conversation = await conversationManager.create(req.body);
        return res.status(200).send(conversation);
    } catch (ex) {
        return res.status(500).send(ex.message);
    }
});

router.get('/all/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        let conversations = await conversationManager.getAll(userId);
        return res.status(200).send(conversations);
    } catch (ex) {
        return res.status(500).send(ex.message);
    }
});

module.exports = router;